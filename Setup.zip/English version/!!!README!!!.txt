WELCOME TO HELLO COM NOTEPAD.

Open Setup.bat to start the setup!

YOU MAY READ THE !!SERIAL!!.txt TO GET THE SERIAL KEY.

BUT IT'S TOTALLY FREE!

ENJOY!!

Sincierly, Hello COM™